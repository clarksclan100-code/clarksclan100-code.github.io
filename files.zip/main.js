// JosiahLucasLandscaping — shared site behavior

document.addEventListener("DOMContentLoaded", () => {
  initNavToggle();
  initFooterYear();
  initScheduleForm();
  initContactForm();
});

/* ---------- Mobile nav ---------- */
function initNavToggle() {
  const toggle = document.querySelector(".nav-toggle");
  const links = document.querySelector(".nav-links");
  if (!toggle || !links) return;

  toggle.addEventListener("click", () => {
    const isOpen = links.classList.toggle("is-open");
    toggle.setAttribute("aria-expanded", String(isOpen));
  });
}

function initFooterYear() {
  const el = document.querySelector("[data-year]");
  if (el) el.textContent = new Date().getFullYear();
}

/* ---------- Schedule page: slot picker + request form ----------
   This site has no live backend, so requests are stored in this
   browser's localStorage under "jll_appointment_requests" and a
   confirmation is shown. Wire the form's data to a real booking
   service (or your own server) before relying on this for real
   appointments — see the comment at the bottom of schedule.html. */

const SLOT_STORAGE_KEY = "jll_appointment_requests";

function initScheduleForm() {
  const slotGrid = document.querySelector("[data-slot-grid]");
  const form = document.querySelector("[data-schedule-form]");
  if (!slotGrid || !form) return;

  const banner = document.querySelector("[data-selected-slot]");
  const hiddenSlotInput = form.querySelector('input[name="slot"]');
  let selectedSlot = null;

  // Mark a few example slots as already booked, just for realism.
  const takenSlots = ["Tue 06/30 — 9:00 AM", "Thu 07/02 — 1:00 PM"];

  slotGrid.querySelectorAll(".slot").forEach((btn) => {
    const value = btn.dataset.slot;
    if (takenSlots.includes(value)) {
      btn.classList.add("is-taken");
      btn.disabled = true;
      btn.setAttribute("aria-disabled", "true");
      return;
    }

    btn.addEventListener("click", () => {
      slotGrid.querySelectorAll(".slot").forEach((b) => b.classList.remove("is-selected"));
      btn.classList.add("is-selected");
      selectedSlot = value;
      if (hiddenSlotInput) hiddenSlotInput.value = value;
      if (banner) {
        banner.textContent = `Selected: ${value}`;
        banner.classList.add("is-visible");
      }
    });
  });

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const status = form.querySelector("[data-form-status]");

    if (!selectedSlot) {
      showStatus(status, "Pick a time slot above before requesting.", "is-error");
      return;
    }

    const data = Object.fromEntries(new FormData(form).entries());
    data.submittedAt = new Date().toISOString();

    try {
      const existing = JSON.parse(localStorage.getItem(SLOT_STORAGE_KEY) || "[]");
      existing.push(data);
      localStorage.setItem(SLOT_STORAGE_KEY, JSON.stringify(existing));
      showStatus(
        status,
        `Request received for ${selectedSlot}. We'll call or text ${data.phone || "you"} to confirm within one business day.`,
        "is-success"
      );
      form.reset();
      slotGrid.querySelectorAll(".slot").forEach((b) => b.classList.remove("is-selected"));
      selectedSlot = null;
      if (banner) banner.classList.remove("is-visible");
    } catch (err) {
      showStatus(status, "Something went wrong saving your request. Please call us instead.", "is-error");
    }
  });
}

/* ---------- Contact form ----------
   No backend is connected yet, so this opens a pre-filled email
   in the visitor's mail app via a mailto: link. Swap this for a
   form service (Formspree, Netlify Forms, etc.) or your own
   endpoint when you're ready to receive these server-side. */
function initContactForm() {
  const form = document.querySelector("[data-contact-form]");
  if (!form) return;

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const status = form.querySelector("[data-form-status]");
    const data = Object.fromEntries(new FormData(form).entries());

    if (!data.name || !data.email || !data.message) {
      showStatus(status, "Please fill in your name, email, and message.", "is-error");
      return;
    }

    const subject = encodeURIComponent(`Website inquiry from ${data.name}`);
    const body = encodeURIComponent(
      `Name: ${data.name}\nEmail: ${data.email}\nPhone: ${data.phone || "—"}\n\n${data.message}`
    );
    window.location.href = `mailto:hello@josiahlucaslandscaping.com?subject=${subject}&body=${body}`;
    showStatus(status, "Opening your email app to send this message...", "is-success");
  });
}

function showStatus(el, message, kind) {
  if (!el) return;
  el.textContent = message;
  el.classList.remove("is-success", "is-error");
  el.classList.add("is-visible", kind);
}
